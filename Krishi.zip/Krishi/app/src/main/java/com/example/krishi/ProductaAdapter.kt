package com.example.krishi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import java.util.ArrayList

class ProductAdapeter(private val Products: ArrayList<Products>) :
    recyclerView.Adapter<ProductAdapeter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.activity_main,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount() = Products.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.text= Products[position].title
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView = itemView.findViewById<ImageView>(R.id.imageView_apple)
        val textView = itemView.findViewById<TextView>(R.id.textView)
    }

}
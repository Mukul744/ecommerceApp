package com.example.krishi

data class Products(val title:String,
                    val Photo:String,
                    val prices:Double) {

}